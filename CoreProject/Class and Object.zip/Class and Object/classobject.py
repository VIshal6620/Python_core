# class Hello:
#     pass
#
#
# print(Hello())


# or

class Hello:
    def __init__(self):
        h = Hello();

    print("Hello world")
