class person:
    def myfunction(self):
        print("hello my name is ram")


# Create an instance of the person class
p = person()

# Call the myfunction method on the instance
p.myfunction()
