class shape:
    name = "Circle"
    print('shape','name')